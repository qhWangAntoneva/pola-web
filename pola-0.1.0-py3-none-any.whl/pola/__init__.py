"""
pola: Python package for calculating critical bandwidth for bimodal distributions

This package implements algorithms to detect the critical bandwidth in kernel density
estimation, which is the smallest bandwidth where the density estimate remains unimodal.
"""

from .bandwidth import (
    BimodalDecomposition,
    Component,
    DipTestResult,
    critical_bandwidth,
    detect_components,
    dip_test,
    find_trough,
    gaussian_kde,
    gaussian_kde_fft,
    silverman_bandwidth,
)
from .bootstrap import (
    BootstrapResult,
    SilvermanTestResult,
    bootstrap_critical_bandwidth,
    silverman_test,
)

__version__ = "0.1.0"
__all__ = [
    "silverman_bandwidth",
    "critical_bandwidth",
    "gaussian_kde",
    "gaussian_kde_fft",
    "find_trough",
    "detect_components",
    "Component",
    "BimodalDecomposition",
    "dip_test",
    "DipTestResult",
    "bootstrap_critical_bandwidth",
    "BootstrapResult",
    "SilvermanTestResult",
    "silverman_test",
]
